# dicoding-android-submission-one
:) This repo for learning purpose. 
Taking courses of Android Expert at ![dicoding.com](dicoding.com) and sponsored by ![Digitalent programe from DIKTI](https://digitalent.kominfo.go.id/).
